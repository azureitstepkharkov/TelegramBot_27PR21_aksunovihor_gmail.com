﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

//
using Telegram.Bot;
using Telegram.Bot.Args;
using Telegram.Bot.Types.Enums;


namespace TelegramBot
{
    public partial class MainForm : Form
    {
        public string token = "518006767:AAEgO09G_Y5NO-__mR_kjetNDlKvnX_4dk0";
        public MainForm()
        {
            InitializeComponent();
        }

        private static Telegram.Bot.TelegramBotClient BOT;
        private string BotName;
        Telegram.Bot.Types.User me;


        private void BtnStart_Click(object sender, EventArgs e)
        {
            var text = token;
            BOT = new Telegram.Bot.TelegramBotClient(text);
            BOT.OnMessage += BotOnMessageReceived;
            BOT.OnCallbackQuery += Bot_OnButton;

            BOT.SetWebhookAsync();
            me = BOT.GetMeAsync().Result;
            BotName = me.Username;
            BOT.StartReceiving();

            BtnStart.Enabled = false;
        }

        private async void BotOnMessageReceived(object sender,
            MessageEventArgs messageEventArgs)
        {
            //сообщение от БОТА
            Telegram.Bot.Types.Message msg = messageEventArgs.Message;
            //реагирую только на тексты 
            //(минус видео,минус картинка, 
            //минус кнопку купить...)
            if (msg == null || msg.Type != MessageType.TextMessage) return;

            String Answer = "Здравствуй," + BotName + "\r\n";
          
            switch (msg.Text)
            {
                
                case "/start":
                    string FirstName = msg.From.FirstName;
                    string LastName = msg.From.LastName;
                    string UserName = msg.From.Username;
                    Answer += "Привет, сколько тебе лет?";
                    Answer += FirstName + " " + LastName + "\r\nСыграем в игру: камень-ножницы-бумага?\r\n";
                    Answer += "/stone - твой камень\r\n/scissors - твои ножницы\r\n/paper - твоя бумага\r\n";
                    #region buttons
                    var keyboard = new Telegram.Bot.Types.ReplyMarkups.InlineKeyboardMarkup(
                                            new Telegram.Bot.Types.InlineKeyboardButtons.InlineKeyboardButton[][]
                                            {
                                                            // First row
                                                            new [] {
                                                                // First column
                                                                new Telegram.Bot.Types.InlineKeyboardButtons.InlineKeyboardCallbackButton("Да?","callback1"),

                                                                // Second column
                                                                new Telegram.Bot.Types.InlineKeyboardButtons.InlineKeyboardCallbackButton("Нет?","callback2"),
                                                            },
                                            }
                                        );
                    #endregion
                    #region exp
                    // */
                    /*
                    var none = new InlineKeyboardCallbackButton("No", "build|no");
                    var yes = "Yes";
                    var betaControl = new InlineKeyboardCallbackButton(yes, "build|betacontrol");
                    var betaNode = new InlineKeyboardCallbackButton(yes, "build|betanode");
                    var betaBoth = new InlineKeyboardCallbackButton(yes, "build|betaboth");
                    InlineKeyboardMarkup menu;
                    menu = new InlineKeyboardMarkup(new[] { betaBoth, none });
                    */
                    #endregion
                    await BOT.SendTextMessageAsync(msg.Chat.Id, Answer,
                        replyMarkup: keyboard);
                    return;

                case "/stone": Answer = "А у меня бумага - ты проиграл"; break;
                case "/scissors": Answer = "А у меня камень - ты проиграл"; break;
                case "/paper": Answer = "А у меня ножницы - ты проиграл"; break;
                default: break;
            }
            await BOT.SendTextMessageAsync(msg.Chat.Id, Answer);

        }

        private async void Bot_OnButton(object sender, CallbackQueryEventArgs e)
        {
            var message = e.CallbackQuery.Message;
            if (e.CallbackQuery.Data == "callback1")
            {
                await BOT.AnswerCallbackQueryAsync(e.CallbackQuery.Id,
     "/stone - твой камень\r\n/scissors - твои ножницы\r\n/paper - твоя бумага\r\n" + e.CallbackQuery.Data, true);
            }
            else
                if (e.CallbackQuery.Data == "callback2")
            {
                await BOT.SendTextMessageAsync(message.Chat.Id, "тест", replyToMessageId: message.MessageId);
                await BOT.AnswerCallbackQueryAsync(e.CallbackQuery.Id); // отсылаем пустое, чтобы убрать "частики" на кнопке
            }
        }
    }
}
